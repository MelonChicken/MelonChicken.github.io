# Junu's Lab — Astro/MDX 전환 구현 명세 (Implementation Spec)

> 목적: `junus-lab-demo.html`의 **정보 구조**를 Astro Content Collections + MDX로 옮겨, Junu가 프로젝트/Lab Note/Weekly Brief를 **파일로 직접 추가·수정**하며 운영할 수 있게 한다. 새 디자인은 만들지 않는다. 기존 디자인은 `src/styles/lab.css`로 그대로 이식한다.

---

## 1. 현재 데모 평가 (짧게)

좋은 점: 정보 위계가 자리를 잡았다 — Research Programs → Projects → Lab Notes가 `related` id로 실제 연결되고, Weekly Lab Brief가 프로젝트가 아니라 루틴으로 분리됐으며, 다크/터미널 정체성도 유지됐다. 상세 패널의 Problem→Method→Result→Next 템플릿도 연구용으로 적절하다.

한계(=전환 이유): 모든 데이터가 HTML 안 `const PROGRAMS/PROJECTS/NOTES` 배열에 박혀 있어 **글을 파일로 추가·수정할 수 없다.** Lab Notes도 실제 글이 아니라 배열 항목이라 "연구 기록 시스템"으로 운영되지 않는다. → Content Collections로 옮기면 글 1개 = 파일 1개가 되어 운영이 가능해진다. 상세 보기도 Astro에서는 드로어 대신 **라우팅된 상세 페이지**가 되므로 "사이드바가 좁다" 문제도 자연 해소된다.

이번 전환에 반영된 수정: 기본 테마 dark, archived 그룹↔status 일치, stable은 대표 완료작만, ArchiTag를 VLM 라벨링 자동화 사례로 재정의, Home 대표 프로젝트 4개 고정, 아이디어 단계는 seed + placeholder.

---

## 2. 최종 정보 구조

### 라우트 (pages)
```
src/pages/
  index.astro              # Home (Lab Dashboard)
  research.astro           # Research (Agenda · Programs · Tracking System)
  projects/index.astro     # Projects (4 groups)
  projects/[slug].astro    # Project detail (Problem→Motivation→Method→Result→Limitation→Next)
  notes/index.astro        # Lab Notes (filters: Type / Domain / Status)
  notes/[slug].astro       # Note detail (type별 템플릿; weekly-brief 전용 레이아웃)
  about.astro
  contact.astro
```

### 콘텐츠 (content collections)
```
src/content/
  config.ts                       # zod 스키마 (제공됨)
  projects/*.mdx                  # 19개 (제공됨)
  notes/*.mdx                     # 6개 시드 (제공됨, 초안 표시)
  research-programs/*.json        # 5개 (제공됨)
  archive/*.mdx                   # 4개 카테고리 (제공됨)
src/styles/lab.css                # 기존 디자인, 그대로
src/scripts/theme.js              # 테마 토글, 기본 lab
```

### 페이지별 역할 / 데이터 소스

| 페이지 | 렌더 블록 | 데이터 쿼리 |
|---|---|---|
| **Home** | Hero · Current Focus · Research Radar(Weekly Brief) · Featured Programs · Featured Projects · Recent Lab Notes | `projects` where `featured` (4개) · `researchPrograms` where `featured` (abx,label,video) · `notes` 최신 4 by `date` · Radar 카피는 정적 + 최신 `type:weekly-brief` 1건 링크 |
| **Research** | Research Agenda(인트로) · Research Programs(전체 카드) · Research Tracking System(루틴/표/주간 cadence) · 흐름도(Question→Weekly Tracking→Selected Paper→Experiment→Project) | `researchPrograms` 전체. Tracking System 섹션은 정적 콘텐츠(아래 §"운영 루틴"). |
| **Projects** | 4그룹 섹션(Research / ML·Data / Product / Archived) | `projects` group별 그룹핑, 그룹 내 정렬: status(seed→growing→stable→archived) 또는 수동 order |
| **Projects/[slug]** | Problem → Motivation → Method → System/Pipeline → Result → Limitation → Next Step → Links → Related Program → Related Notes | 해당 entry + `program` 조인 + `relatedNotes` 조인. 본문은 MDX render. |
| **Lab Notes** | Featured Notes · Recent Notes · 필터(Type/Domain/Status) | `notes` 전체. 필터는 초기엔 클라이언트 사이드 단순 토글. |
| **Notes/[slug]** | type별 템플릿. `weekly-brief`는 Tracked Fields·Key Papers·Tools/Datasets/Repos·Why it matters·Connection to agenda·Possible Experiments·Selected for Review·Next 전용 레이아웃 | 해당 entry + `relatedProject`/`relatedNotes` 조인 |
| **Archive** | Coding Test / Course / Old Project / Velog 카테고리 | `archive` collection, `order` 정렬 |

---

## 3. 콘텐츠 스키마 (요약 — 정식 정의는 `src/content/config.ts`)

규칙(중요):
- `status`: **seed**(아이디어) · **growing**(진행 중) · **stable**(대표 완료작만) · **archived**.
- `group: archived` ⇔ `status: archived` (항상 함께).
- 교차참조는 **slug == 파일명 == entry id**로 해석한다.

**Project frontmatter**
```yaml
title: ; slug: ; status: ; group: research|ml|product|archived
domain: []            # 표시용 태그
program:              # research-program id (abx|pose|label|video|sys)
stack: []; roles: []
dataset: ; output: 
repo: ; repoPrivate: ; deploy: ; demo: ; notion:
relatedNotes: []      # note slugs
featured:             # Home 노출 여부
summary: ; problem:
# 본문(MDX): Motivation / Method / Pipeline / Result / Limitation / Next
```

**Lab Note frontmatter**
```yaml
title: ; slug: ; type: weekly-brief|paper-review|experiment-log|implementation-note|learning-note|retrospective
status: ; domain: []; methods: []
date: ; readTime:
relatedProject:       # project slug
relatedNotes: []
summary:
# 본문(MDX): Problem/Question · What I tried · What I found · Limitation · Next Step
```

**Weekly Lab Brief frontmatter (note의 type=weekly-brief)**
```yaml
title: "Weekly Lab Brief: 2026-06-29"; slug: weekly-lab-brief-2026-06-29
type: weekly-brief; status: ; domain: []
trackedFields: []; outputs: []
selectedForReview: ; next:
# 본문(MDX): Key Papers / Tools·Datasets·Repos / Why it matters / Connection to agenda / Possible Experiments
```

**Research Program (json)**
```json
{ "id","title","status","statusLabel","question","matters",
  "methods":[], "relatedProjects":[/*slugs*/], "relatedNotes":[/*slugs*/], "featured":bool }
```

---

## 4. Home에 노출할 대표 콘텐츠 (확정)

- **Featured Projects (정확히 4개, 이 순서):** WildlifeVision Baseline · Be MOre Duck · ArchiTag · OULAD Early At-Risk Prediction → 각 mdx에 `featured: true`.
- **Featured Research Programs (3):** Animal Behavior Analysis(abx) · Behavior Labeling Automation(label) · Long Video Understanding(video) → program json에 `featured: true`.
- **Research Radar / Weekly Lab Brief:** 정적 설명 + 최신 `type:weekly-brief` 1건으로 링크. "AI 브리핑을 올리는 곳"이 아니라 "내가 운영하는 추적·큐레이션 루틴"으로 프레이밍(아래 §운영 루틴 카피 사용).
- **Recent Lab Notes:** `date` 최신 4건.
- **Current Focus / Lab Status:** 정적(또는 작은 site config). 현재값: reading=semi-supervised behavior recognition / experimenting=Be MOre Duck·ArchiTag / next candidate=labeling-automation prototype.

---

## 5. Codex 구현 지시서 (순서대로)

1. **프로젝트 생성**: `npm create astro@latest` (minimal, TypeScript). `npx astro add mdx` 로 MDX 통합 추가.
2. **스캐폴드 이식**: 제공된 `astro-scaffold/src/content`, `src/styles`, `src/scripts`를 프로젝트 `src/`에 복사. `config.ts`는 Astro 5 content layer(glob loader) 기준이다.
3. **글로벌 스타일**: `src/styles/lab.css`를 BaseLayout에서 import. **재디자인 금지** — 토큰/클래스 그대로 사용한다.
4. **BaseLayout.astro**: `<html data-theme="lab">`로 시작, 헤더(brand `⚗ Junu's Lab` + nav + `#themeSwitch` 버튼 + status strip) + footer를 데모와 동일 마크업/클래스로 구성. `src/scripts/theme.js`의 `initTheme()`를 client script로 호출(기본 dark, localStorage 지속).
5. **컴포넌트 추출**(데모 클래스 재사용): `Card.astro`, `Badge.astro`(status별 클래스 `st-seed|st-growing|st-stable|st-archived`), `Tag.astro`, `Eyebrow.astro`, `Panel.astro`, `Pipeline.astro`, `Metabox.astro`, `RelatedList.astro`. 마크업은 데모의 `.card/.badge/.tag/.panel/.dblock/.metabox/.related`를 그대로 옮긴다.
6. **유틸**: `src/lib/content.ts`에 헬퍼 — `getProjectsByGroup()`, `getFeaturedProjects()`, `getFeaturedPrograms()`, `getRecentNotes(n)`, `resolveRelated(slugs, collection)`(slug→entry). 상태 정렬 가중치 `{seed:0,growing:1,stable:2,archived:3}`.
7. **Home(index.astro)**: §4 쿼리로 6개 블록 렌더. 데모의 bento/패널 클래스 재사용. Radar 섹션 카피는 §운영 루틴 사용.
8. **Research(research.astro)**: `researchPrograms` 전체 카드 + Tracking System 섹션(표 + 주간 cadence + 흐름도). 흐름도는 데모 `.pipeline` 클래스 재사용.
9. **Projects(index + [slug])**: group별 그룹 렌더. `[slug]`는 `getStaticPaths()`로 생성, 상세 템플릿(§2 표) + `program`/`relatedNotes` 조인. frontmatter에 narrative 필드가 없고 본문이 placeholder면 "작성 예정" 안내를 그대로 보여준다.
10. **Lab Notes(index + [slug])**: 목록 + 필터(Type/Domain/Status, 클라이언트 토글). `[slug]`는 type 분기 — `weekly-brief`는 전용 레이아웃(Tracked Fields/Selected for Review 강조), 나머지는 공통 레이아웃. "Selected 1 of N" 같은 큐레이션 표현 유지.
11. **Archive(about/contact)**: `archive` collection 렌더 + About(Profile/Interests/Stack/Timeline/Goal) + Contact(이메일/GitHub/Velog/repo). 데모 마크업 재사용.
12. **관계 무결성 체크**: 빌드 시 `relatedProject`/`relatedNotes`/`relatedProjects`의 slug가 실제 entry와 매칭되는지 단순 assert(없으면 경고). 깨진 링크 방지.
13. **검증**: `astro check` + `astro build`. status/group 규칙(archived↔archived), featured 4개, weekly-brief는 notes에만 존재하는지 확인.

배포: 기존처럼 GitHub Pages면 `@astrojs/...` static output + `base`/`site` 설정. (현재 repo가 `MelonChicken.github.io`이므로 root 배포.)

---

## 6. 디자인 보존 원칙 (필수)

- `src/styles/lab.css`는 데모에서 **그대로** 추출한 것 — 색/폰트/라운드/보더/그림자 토큰을 바꾸지 않는다.
- 새 색상·그라데이션·glassmorphism·새 폰트·과한 애니메이션 **금지**(기존 지침 유지).
- 상세는 드로어가 아니라 **페이지**로 — 읽기 폭 문제 해결. (원하면 목록에서 quick-view 드로어를 옵션으로 추가 가능하나 필수 아님.)
- 폰트는 SUIT 단일, 터미널 라벨은 `>` 프리픽스 + 대문자 + letter-spacing(데모 `.eyebrow`).

---

## 부록 A. 19개 프로젝트 매핑 (적용된 수정 포함)

| slug | group | status | program | featured |
|---|---|---|---|---|
| wildlifevision-baseline | research | stable | abx | ✅ |
| be-more-duck | research | growing | abx | ✅ |
| architag-vlm-labeling | research | growing | label | ✅ |
| wildlife-behavior-analyzer | research | seed | abx | |
| wildlife-metadata-fusion | research | seed | label | |
| oulad-at-risk-prediction | ml | stable | sys | ✅ |
| hybridrag | ml | stable | sys | |
| research-radar-ai | ml | stable | sys | |
| memory-egg | product | stable | sys | |
| junus-lab-portfolio | product | stable | sys | |
| ddokbath | product | stable | sys | |
| habi | archived | archived | — | |
| weathercall119 | archived | archived | — | |
| n8n-shortform-automation | archived | archived | — | |
| f1-qna-bot | archived | archived | — | |
| govpulse | archived | archived | — | |
| opomo | archived | archived | — | |
| school-notice-bot | archived | archived | — | |
| newsboy | archived | archived | — | |

판단 메모: `habi`, `weathercall119`는 실제 완료작이지만 연구 포지셔닝과 거리가 있어 Archived로 내렸다. 다시 전면에 보이고 싶으면 frontmatter의 `group`/`status`만 바꾸면 된다(이게 MDX 운영의 핵심 이점).

ArchiTag: `group: research` 유지하되 도메인을 `VLM · Weak Supervision · Labeling Automation`으로, 설명을 "동물행동 라벨링에 전이되는 VLM 라벨링 자동화 사례"로 재정의(동물행동 프로젝트로 표기하지 않음).

## 부록 B. 운영 루틴 (Research Radar 카피 + 새 글 추가법)

**Radar 프레이밍(정적 카피로 사용):** "매주 ChatGPT로 추적 분야의 raw 브리핑을 생성해 Notion에 저장하고, 그중 내 agenda에 연결되는 소수만 선별한다. 여기 공개되는 것은 내가 읽고 해석한 결과뿐 — 브리핑은 센싱 도구이지 결과물이 아니다." (저장 위치: Notion=원본, 블로그/Lab Notes=선별 노트, 포트폴리오=월간 종합.)

**새 글 추가:**
- 주간 브리핑: `src/content/notes/weekly-lab-brief-YYYY-MM-DD.mdx` 추가 → Home/Notes에 자동 노출.
- 논문 리뷰/실험 로그: `notes/<slug>.mdx` (type 지정) + `relatedProject`로 프로젝트와 연결.
- 새 프로젝트: `projects/<slug>.mdx` + `group/status/program/relatedNotes` 지정.
- 시드 노트의 본문 상단 `⚠️ 시드 콘텐츠` 콜아웃은 실제 글로 채우면 삭제.

---

첨부: `astro-scaffold.zip` — 위 `src/content`, `src/styles`, `src/scripts`와 `config.ts`, README 포함. 그대로 복사 후 §5 순서로 페이지만 구현하면 된다.
